﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Birdie: MonoBehaviour
{
    public float up;                 //upward force of the flap - made public to edit in front end
    private bool dead = false;      // this checks for collision - is the bird dead
    private Rigidbody2D rb;           //holds Rigidbody reference component of the block

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();     //Gets component for RigidBody
    }

    // Update is called once per frame
    void Update()
    {

        if (dead == false)              //no controlling flaps if the player has already died
        {
            if (Input.GetKeyDown("space"))      //detects if the user is pressing the spacebar down
            {
                rb.velocity = Vector2.zero;     //zero's out the y velocity of the bird from before
                rb.AddForce(new Vector2(0, up)); //adds an upward force to the bird so that it appears to "flap"

            }
        }
    }

    //When the bird collides with something enter this function
    void OnCollisionEnter2D(Collision2D collision)
    {
        rb.velocity = Vector2.zero;         //Set velocity of bird to 0 so that it stops moving
        dead = true;                        //Sets the boolean true - bird is now dead

        if (dead == true)
        {
            SceneManager.LoadScene(2);      //when the bird dies, load game over scene
        }
    }


}


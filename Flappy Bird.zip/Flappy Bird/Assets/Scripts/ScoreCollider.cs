﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreCollider : MonoBehaviour
{
    //when the pillars collide with the boxcollider it triggers the function
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //adds one to the overall score of the player
        scorescript.scoreValue += 1;
    }
}

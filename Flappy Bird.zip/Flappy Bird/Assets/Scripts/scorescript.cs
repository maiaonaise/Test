﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scorescript : MonoBehaviour
{
    //create a variable to save the score for the player
    public static int scoreValue = 0;
    //text  variable to display in the UI
    Text score;

    // Start is called before the first frame update
    void Start()
    {
        //Gets the text component and saves it in the score variable to be used later
        score = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        //updates scoreValue
        score.text = "Score: " + scoreValue;
    }
}

